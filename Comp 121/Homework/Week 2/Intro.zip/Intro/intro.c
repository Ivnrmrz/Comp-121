#include <stdio.h>

int main(){
    printf(" Ivan Ramirez\n Mechatronics Engineering\n 2025\n ""go ahead\n");   
}