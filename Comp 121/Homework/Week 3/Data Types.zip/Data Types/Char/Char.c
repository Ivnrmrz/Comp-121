#include <stdio.h>

int main(){
    char grade = 'A' ;
        printf("My letter grade for this class is a %c \n", grade);
}