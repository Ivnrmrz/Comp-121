#include <stdio.h>

int main(){
    float grade  = 99.47 ;
        printf("I have a %.2f in my comp class \n", grade);
}