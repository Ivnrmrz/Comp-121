#include <stdio.h>

int main(){
    double size_of_eiffel_tower_meters = 7.62490582340458723 ;
        printf("The Eiffel Tower could be %+d meters tall \n", size_of_eiffel_tower_meters);
}