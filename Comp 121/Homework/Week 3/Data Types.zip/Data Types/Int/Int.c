#include <stdio.h>

int main(){
    int age = 18;
    printf("I am %d years old. \n", age);
}