#include <stdio.h>

int main() {
    int class_of, classes;
    class_of = 2021 ;
    classes = 5 ;
    printf("I graduated from high school in %d and I am taking %d classes this semester. \n ",class_of, classes);
    
}