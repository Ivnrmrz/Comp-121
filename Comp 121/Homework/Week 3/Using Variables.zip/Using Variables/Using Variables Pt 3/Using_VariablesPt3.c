#include <stdio.h>

int main() {
    int Josh, Steve, Nancy;
    Josh = 6;
    Steve = Josh + 2; 
    Nancy = Josh - 1;
    
    printf(" Josh:  %d \n Steve: %d \n Nancy: %d \n", Josh, Steve, Nancy);
    
}