#include <stdio.h>

int main() {
    int my_apples = 7;
    printf("I Have %d apples. \n ", my_apples);
    
}